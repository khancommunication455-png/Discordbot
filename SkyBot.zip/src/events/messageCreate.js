import { Events, EmbedBuilder } from 'discord.js';
import { addXp, getLevelingConfig } from '../utils/levelingUtil.js';
import { getDb } from '../utils/db.js';
import { enqueueTTS, getTTSState } from '../services/ttsService.js';

export default {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot) return;
    if (!message.guild)     return;

    const guildId = message.guildId;
    const db      = getDb();

    // ── Custom Commands ────────────────────────────────────────────────
    const cfg     = db.data.guildConfig?.[guildId];
    const prefix  = cfg?.prefix ?? '!';
    const content = message.content.trim();

    if (content.startsWith(prefix) || content.startsWith('!')) {
      const trigger = content.toLowerCase().split(' ')[0]; // e.g. "!rules"
      const cmd     = cfg?.customCmds?.[trigger] ?? cfg?.customCmds?.[trigger.slice(prefix.length)];

      if (cmd) {
        const embed = new EmbedBuilder()
          .setColor(cmd.color ?? 0x5865f2)
          .setTimestamp();
        if (cmd.title)    embed.setTitle(cmd.title);
        if (cmd.response) embed.setDescription(cmd.response);
        await message.channel.send({ embeds: [embed] }).catch(() => {});
        return; // don't process XP for command triggers
      }
    }

    // ── TTS: read messages from configured channel ──────────────────────
    const ttsChannelId = db.data.ttsChannels?.[guildId];
    if (ttsChannelId && message.channelId === ttsChannelId) {
      const state = getTTSState(guildId);
      if (state && message.content.trim()) {
        await enqueueTTS(
          message.guild,
          message.content,
          message.member?.displayName ?? message.author.username
        ).catch(err => console.error('[TTS] Enqueue error:', err.message));
      }
    }

    // ── XP Leveling ────────────────────────────────────────────────────
    const config = getLevelingConfig(guildId);
    if (config?.enabled) {
      try {
        const result = await addXp(guildId, message.author.id, client);
        if (result?.leveledUp) {
          const lvlChannel = config.channelId
            ? message.guild.channels.cache.get(config.channelId) ?? message.channel
            : message.channel;

          const lvlMsg = (config.message ?? '🎉 {user} leveled up to **Level {level}**!')
            .replace('{user}',  `<@${message.author.id}>`)
            .replace('{level}', result.level);

          const embed = new EmbedBuilder()
            .setColor(0xffd700)
            .setDescription(lvlMsg)
            .setThumbnail(message.author.displayAvatarURL())
            .setTimestamp();

          await lvlChannel.send({ embeds: [embed] }).catch(() => {});
        }
      } catch (err) {
        console.error('[XP] Error:', err.message);
      }
    }
  },
};
