/**
 * hypixel.js — Multi-API fallback chain (no official key needed)
 *
 * SkyCrypt API docs: https://sky.shiiyu.moe/api
 * Slothpixel docs:  https://slothpixel.me/docs
 */
import axios from 'axios';

// ── API Clients ────────────────────────────────────────────────────────────
const MOJANG     = axios.create({ baseURL: 'https://api.mojang.com/',        timeout: 8_000 });
const MINETOOLS  = axios.create({ baseURL: 'https://api.minetools.eu/',       timeout: 8_000 });
const SKYCRYPT   = axios.create({ baseURL: 'https://sky.shiiyu.moe/api/v2/', timeout: 20_000 });
const SLOTHPIXEL = axios.create({ baseURL: 'https://api.slothpixel.me/api/', timeout: 12_000 });
const HYPIXEL    = axios.create({ baseURL: 'https://api.hypixel.net/',        timeout: 10_000 });

function hasKey() { return !!process.env.HYPIXEL_API_KEY; }

// ── UUID Lookup ─────────────────────────────────────────────────────────────
export async function getUUID(ign) {
  try {
    const { data } = await MOJANG.get(`users/profiles/minecraft/${ign}`);
    if (data?.id) return { id: data.id.replace(/-/g, ''), name: data.name };
  } catch {}

  try {
    const { data } = await MINETOOLS.get(`uuid/${ign}`);
    if (data?.id && data.id !== 'INVALID') return { id: data.id.replace(/-/g, ''), name: data.name };
  } catch {}

  try {
    const { data } = await SLOTHPIXEL.get(`players/${ign}`);
    if (data?.uuid) return { id: data.uuid.replace(/-/g, ''), name: data.username };
  } catch {}

  throw new Error(`Player \`${ign}\` not found. Check the spelling.`);
}

// ── Skyblock Profiles ───────────────────────────────────────────────────────
export async function getSkyblockProfiles(uuid) {
  // SkyCrypt — try /profiles/:uuid (returns all profiles)
  try {
    const { data } = await SKYCRYPT.get(`profiles/${uuid}`);
    if (data && !data.error && data.profiles) {
      return Object.entries(data.profiles).map(([id, p]) => normalizeSkyCryptProfile(id, p, uuid));
    }
  } catch (e) {
    console.warn('[Hypixel] SkyCrypt /profiles failed:', e.message);
  }

  // SkyCrypt — fallback to /profile/:uuid (selected profile only)
  try {
    const { data } = await SKYCRYPT.get(`profile/${uuid}`);
    if (data && !data.error) {
      const id = data.profile_id ?? 'unknown';
      return [normalizeSkyCryptProfile(id, data, uuid)];
    }
  } catch (e) {
    console.warn('[Hypixel] SkyCrypt /profile failed:', e.message);
  }

  // Official Hypixel API
  if (hasKey()) {
    try {
      const { data } = await HYPIXEL.get('skyblock/profiles', {
        params: { key: process.env.HYPIXEL_API_KEY, uuid },
      });
      if (data.success && data.profiles?.length) return data.profiles;
    } catch (e) {
      console.warn('[Hypixel] Official API failed:', e.message);
    }
  }

  throw new Error('Could not fetch SkyBlock profiles. SkyCrypt may be temporarily down — try again in a moment.');
}

function normalizeSkyCryptProfile(profileId, profile, uuid) {
  // Handle both /profiles and /profile response shapes
  const members = profile.members ?? {};
  const member  = members[uuid] ?? profile; // /profile returns member data at root

  const exp = member.player_data?.experience ?? {};

  return {
    profile_id: profileId,
    cute_name:  profile.cute_name ?? 'Unknown',
    selected:   profile.selected  ?? false,
    banking:    { balance: profile.banking?.balance ?? 0 },
    members: {
      [uuid]: {
        player_data: {
          experience: {
            SKILL_FARMING:      exp.SKILL_FARMING      ?? member.experience_skill_farming      ?? 0,
            SKILL_MINING:       exp.SKILL_MINING       ?? member.experience_skill_mining       ?? 0,
            SKILL_COMBAT:       exp.SKILL_COMBAT       ?? member.experience_skill_combat       ?? 0,
            SKILL_FORAGING:     exp.SKILL_FORAGING     ?? member.experience_skill_foraging     ?? 0,
            SKILL_FISHING:      exp.SKILL_FISHING      ?? member.experience_skill_fishing      ?? 0,
            SKILL_ENCHANTING:   exp.SKILL_ENCHANTING   ?? member.experience_skill_enchanting   ?? 0,
            SKILL_ALCHEMY:      exp.SKILL_ALCHEMY      ?? member.experience_skill_alchemy      ?? 0,
            SKILL_TAMING:       exp.SKILL_TAMING       ?? member.experience_skill_taming       ?? 0,
            SKILL_CARPENTRY:    exp.SKILL_CARPENTRY    ?? member.experience_skill_carpentry    ?? 0,
            SKILL_RUNECRAFTING: exp.SKILL_RUNECRAFTING ?? member.experience_skill_runecrafting ?? 0,
          },
        },
        dungeons:              member.dungeons    ?? {},
        slayer:                { slayer_bosses: member.slayer_bosses ?? member.slayer?.slayer_bosses ?? {} },
        currencies:            { coin_purse: member.currencies?.coin_purse ?? member.coin_purse ?? member.purse ?? 0 },
        leveling:              { experience: member.leveling?.experience ?? 0 },
        fairy_souls_collected: member.fairy_souls_collected ?? member.fairy_souls?.total ?? 0,
        mining_core:           member.mining_core   ?? {},
        jacobs_contest:        member.jacobs_contest ?? {},
      },
    },
  };
}

export async function getActiveProfile(uuid) {
  const profiles = await getSkyblockProfiles(uuid);
  if (!profiles?.length) throw new Error('No SkyBlock profiles found.');
  return profiles.find(p => p.selected) ?? profiles[0];
}

// ── Player Auctions ─────────────────────────────────────────────────────────
export async function getPlayerAuctions(uuid) {
  try {
    const { data } = await SKYCRYPT.get(`auctions/${uuid}`);
    if (data?.auctions) {
      return data.auctions.map(a => ({
        uuid:               a.uuid ?? '',
        item_name:          a.item_name ?? 'Unknown Item',
        starting_bid:       a.starting_bid ?? a.price ?? 0,
        highest_bid_amount: a.highest_bid  ?? a.highest_bid_amount ?? 0,
        bin:                a.bin    ?? false,
        end:                a.end    ?? Date.now(),
        claimed:            a.claimed ?? false,
      }));
    }
  } catch (e) {
    console.warn('[Hypixel] SkyCrypt auctions failed:', e.message);
  }

  if (hasKey()) {
    try {
      const { data } = await HYPIXEL.get('skyblock/auction', {
        params: { key: process.env.HYPIXEL_API_KEY, uuid },
      });
      if (data.success) return data.auctions ?? [];
    } catch {}
  }

  throw new Error('Could not fetch auctions. Try again in a moment.');
}

// ── AH Page ─────────────────────────────────────────────────────────────────
export async function getAHPage(page = 0) {
  if (!hasKey()) return { auctions: [], totalPages: 0 };
  try {
    const { data } = await HYPIXEL.get('skyblock/auctions', {
      params: { key: process.env.HYPIXEL_API_KEY, page },
    });
    if (data.success) return data;
  } catch {}
  return { auctions: [], totalPages: 0 };
}

// ── Bazaar ───────────────────────────────────────────────────────────────────
export async function getBazaar() {
  try {
    const { data } = await SLOTHPIXEL.get('skyblock/bazaar');
    if (data && Object.keys(data).length > 5) return data;
  } catch (e) {
    console.warn('[Hypixel] Slothpixel bazaar failed:', e.message);
  }

  if (hasKey()) {
    try {
      const { data } = await HYPIXEL.get('skyblock/bazaar', {
        params: { key: process.env.HYPIXEL_API_KEY },
      });
      if (data.success) return data.products;
    } catch {}
  }

  throw new Error('Bazaar data temporarily unavailable. Try again later.');
}

// ── Player Data ──────────────────────────────────────────────────────────────
export async function getPlayerData(uuid) {
  try {
    const { data } = await SLOTHPIXEL.get(`players/${uuid}`);
    if (data?.username) {
      return {
        newPackageRank: data.rank ?? 'NON',
        achievements:   data.achievements ?? {},
        displayname:    data.username,
      };
    }
  } catch {}

  if (hasKey()) {
    try {
      const { data } = await HYPIXEL.get('player', {
        params: { key: process.env.HYPIXEL_API_KEY, uuid },
      });
      if (data.success) return data.player;
    } catch {}
  }

  return { newPackageRank: 'NON', achievements: {}, displayname: '' };
}

// ── Helpers ───────────────────────────────────────────────────────────────────
export function cleanItemName(name = '') { return name.replace(/§./g, '').trim(); }

export function estimateNetworth(profile, uuid) {
  const member = profile?.members?.[uuid];
  if (!member) return 0;
  const purse = member.currencies?.coin_purse ?? member.coin_purse ?? 0;
  const bank  = profile.banking?.balance ?? 0;
  return purse + bank;
}
