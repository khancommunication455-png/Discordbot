/**
 * ttsService.js — Production TTS for Railway
 * Uses StreamElements API (free, no key, works on Railway)
 * Handles Roman Urdu, Hindi script, Urdu script, English
 */
import {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  StreamType,
} from '@discordjs/voice';
import { Readable, pipeline } from 'stream';
import https from 'https';
import http from 'http';

const ttsState = new Map(); // guildId → { player, connection, queue, active }

// ── HTTP/HTTPS fetch returning Buffer ────────────────────────────────────
function fetchBuffer(urlStr, headers = {}) {
  return new Promise((resolve, reject) => {
    const url    = new URL(urlStr);
    const client = url.protocol === 'https:' ? https : http;

    const options = {
      hostname: url.hostname,
      port:     url.port || (url.protocol === 'https:' ? 443 : 80),
      path:     url.pathname + url.search,
      method:   'GET',
      headers:  {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Accept':     'audio/mpeg, audio/*, */*',
        ...headers,
      },
      timeout: 12000,
    };

    const req = client.request(options, (res) => {
      // Follow redirects
      if ((res.statusCode === 301 || res.statusCode === 302) && res.headers.location) {
        fetchBuffer(res.headers.location, headers).then(resolve).catch(reject);
        return;
      }
      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode} from ${url.hostname}`));
        return;
      }
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end',  ()    => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    });

    req.on('error',   reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Request timed out')); });
    req.end();
  });
}

// ── TTS Providers ─────────────────────────────────────────────────────────

// StreamElements — free, reliable, works on Railway, no API key
const SE_VOICES = {
  en:   'Brian',   // English + Roman Urdu (Hinglish)
  hi:   'Brian',   // Hindi transliterated → Brian handles it
  ur:   'Brian',   // Urdu script
  male: 'Brian',
};

async function fetchStreamElements(text, voice = 'Brian') {
  const clean = text
    .replace(/[<>&"']/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 450);

  const encoded = encodeURIComponent(clean);
  const url     = `https://api.streamelements.com/kappa/v2/speech?voice=${voice}&text=${encoded}`;

  const buf = await fetchBuffer(url, {
    'Referer': 'https://streamelements.com/',
  });

  if (buf.length < 200) throw new Error('StreamElements returned empty audio');
  return buf;
}

// TikTok TTS — another free source as backup
async function fetchTikTokTTS(text) {
  const clean   = text.slice(0, 200).replace(/"/g, "'");
  const encoded = encodeURIComponent(clean);
  const url     = `https://tiktok-tts.weilbyte.net/api/generate?text=${encoded}&voice=en_us_001`;
  try {
    const buf = await fetchBuffer(url);
    if (buf.length > 500) return buf;
    throw new Error('empty');
  } catch {
    throw new Error('TikTok TTS failed');
  }
}

// ── Language detection ─────────────────────────────────────────────────────
function detectLang(text) {
  if (/[\u0600-\u06FF]/.test(text)) return 'ur';  // Urdu script
  if (/[\u0900-\u097F]/.test(text)) return 'hi';  // Hindi/Devanagari
  // Roman Urdu keywords
  if (/\b(aur|hai|hain|kya|yeh|woh|bhai|yaar|nahi|nahin|theek|karo|karna|jana|aana|kyun|kaise|matlab|phir|lekin|magar|agar|toh|bilkul|shukriya|inshallah|mashallah|subhanallah|alhamdulillah|accha|chalte|abhi|jaldi|bohat|bohot|zyada|thora|sirf|bas|pakka|zaroor)\b/i.test(text)) {
    return 'roman_ur';
  }
  return 'en';
}

async function fetchTTS(text) {
  const lang = detectLang(text);
  console.log(`[TTS] Lang detected: ${lang} for: "${text.slice(0, 40)}"`);

  // All languages → StreamElements Brian (handles Hinglish well)
  // Brian is the most natural-sounding voice for mixed language content
  try {
    return await fetchStreamElements(text, 'Brian');
  } catch (err) {
    console.warn('[TTS] StreamElements failed:', err.message, '— trying backup');
    // Backup: TikTok TTS
    try {
      return await fetchTikTokTTS(text);
    } catch {
      throw new Error('All TTS providers failed. Check internet connectivity on Railway.');
    }
  }
}

// ── Voice Connection ───────────────────────────────────────────────────────
export async function setupTTS(guild, voiceChannelId) {
  // Clean up existing
  const old = ttsState.get(guild.id);
  if (old) {
    try { old.player.stop(true); } catch {}
    try { old.connection.destroy(); } catch {}
    await new Promise(r => setTimeout(r, 500));
    ttsState.delete(guild.id);
  }

  const connection = joinVoiceChannel({
    channelId:      voiceChannelId,
    guildId:        guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf:       false,
    selfMute:       false,
  });

  // Give connection time to establish without blocking
  await new Promise(r => setTimeout(r, 2000));

  const player = createAudioPlayer();
  connection.subscribe(player);

  const state = {
    player,
    connection,
    queue:   [],
    active:  false,
    guildId: guild.id,
  };
  ttsState.set(guild.id, state);

  player.on(AudioPlayerStatus.Idle, () => {
    state.active = false;
    setTimeout(() => processQueue(guild.id), 250);
  });

  player.on('error', err => {
    console.error('[TTS] Player error:', err.message);
    state.active = false;
    setTimeout(() => processQueue(guild.id), 500);
  });

  connection.on('error', err => {
    console.error('[TTS] Connection error:', err.message);
  });

  connection.on(VoiceConnectionStatus.Disconnected, () => {
    console.warn('[TTS] Bot disconnected from voice');
    ttsState.delete(guild.id);
  });

  connection.on(VoiceConnectionStatus.Destroyed, () => {
    ttsState.delete(guild.id);
  });

  return state;
}

// ── Queue ──────────────────────────────────────────────────────────────────
export async function enqueueTTS(guild, rawText, username) {
  const state = ttsState.get(guild.id);
  if (!state) return false;

  // Clean message text
  const text = rawText
    .replace(/<@!?\d+>/g, 'someone')
    .replace(/<#\d+>/g, 'a channel')
    .replace(/<@&\d+>/g, 'a role')
    .replace(/<a?:\w+:\d+>/g, '')          // custom emoji
    .replace(/https?:\/\/\S+/gi, 'link')
    .replace(/```[\s\S]*?```/g, 'code block')
    .replace(/`[^`]+`/g, 'code')
    .replace(/[*_~|]/g, '')                 // markdown
    .replace(/\n+/g, ' ')
    .trim();

  if (!text || text.length === 0) return false;
  if (text.length > 500) return false;     // skip very long messages

  const fullText = `${username} says, ${text}`;
  state.queue.push(fullText);

  if (!state.active) processQueue(guild.id);
  return true;
}

async function processQueue(guildId) {
  const state = ttsState.get(guildId);
  if (!state || state.active || state.queue.length === 0) return;

  const text   = state.queue.shift();
  state.active = true;

  console.log(`[TTS] Speaking (${guildId}): "${text.slice(0, 60)}"`);

  try {
    const buffer   = await fetchTTS(text);
    const readable = new Readable({
      read() {
        this.push(buffer);
        this.push(null);
      }
    });

    const resource = createAudioResource(readable, {
      inputType:    StreamType.Arbitrary,
      inlineVolume: true,
    });
    resource.volume?.setVolume(1.0);
    state.player.play(resource);

  } catch (err) {
    console.error('[TTS] processQueue error:', err.message);
    state.active = false;
    setTimeout(() => processQueue(guildId), 300);
  }
}

// ── Controls ───────────────────────────────────────────────────────────────
export function stopTTS(guildId) {
  const state = ttsState.get(guildId);
  if (!state) return;
  state.queue  = [];
  state.active = false;
  try { state.player.stop(true); } catch {}
  try { state.connection.destroy(); } catch {}
  ttsState.delete(guildId);
}

export function clearTTSQueue(guildId) {
  const state = ttsState.get(guildId);
  if (state) { state.queue = []; state.active = false; }
}

export function getTTSState(guildId) {
  return ttsState.get(guildId) ?? null;
}

export async function moveTTS(guild, newChannelId) {
  const state = ttsState.get(guild.id);
  if (!state) return false;
  try {
    const newConn = joinVoiceChannel({
      channelId:      newChannelId,
      guildId:        guild.id,
      adapterCreator: guild.voiceAdapterCreator,
      selfDeaf:       false,
    });
    await new Promise(r => setTimeout(r, 1000));
    try { state.connection.destroy(); } catch {}
    state.connection = newConn;
    newConn.subscribe(state.player);
    return true;
  } catch {
    return false;
  }
}
