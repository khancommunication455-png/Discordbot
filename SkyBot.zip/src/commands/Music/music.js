import {
  SlashCommandBuilder, EmbedBuilder,
  ButtonBuilder, ButtonStyle, ActionRowBuilder,
} from 'discord.js';
import {
  joinVoiceChannel, createAudioPlayer, createAudioResource,
  AudioPlayerStatus, VoiceConnectionStatus, entersState,
  getVoiceConnection,
} from '@discordjs/voice';
import play from 'play-dl';
import { errorEmbed, successEmbed, infoEmbed } from '../../utils/embeds.js';

function getQueue(client, guildId) {
  if (!client.musicQueues.has(guildId)) {
    client.musicQueues.set(guildId, {
      tracks: [],
      player: null,
      connection: null,
      current: null,
      volume: 0.5,
      loop: false,
      textChannel: null,
    });
  }
  return client.musicQueues.get(guildId);
}

async function playNext(client, guildId) {
  const q = getQueue(client, guildId);
  if (!q.tracks.length) {
    q.current = null;
    q.textChannel?.send({ embeds: [infoEmbed('Queue Empty', 'No more tracks. Add more with `/music play`!')] });
    return;
  }

  const track = q.tracks.shift();
  q.current = track;

  try {
    const stream = await play.stream(track.url, { quality: 2 });
    const resource = createAudioResource(stream.stream, {
      inputType: stream.type,
      inlineVolume: true,
    });
    resource.volume?.setVolume(q.volume);
    q.player.play(resource);

    q.textChannel?.send({
      embeds: [new EmbedBuilder()
        .setColor(0x1db954)
        .setTitle('🎵 Now Playing')
        .setDescription(`**[${track.title}](${track.url})**`)
        .addFields(
          { name: 'Duration', value: track.duration, inline: true },
          { name: 'Added by', value: `<@${track.requestedBy}>`, inline: true },
        )
        .setThumbnail(track.thumbnail)
        .setTimestamp()
      ],
    });
  } catch (err) {
    q.textChannel?.send({ embeds: [errorEmbed('Playback Error', `Skipped: ${err.message}`)] });
    playNext(client, guildId);
  }
}

export default {
  data: new SlashCommandBuilder()
    .setName('music')
    .setDescription('Music player')
    .addSubcommand(s => s
      .setName('play')
      .setDescription('Play a song (URL or search query)')
      .addStringOption(o => o.setName('query').setDescription('YouTube URL or search term').setRequired(true))
    )
    .addSubcommand(s => s.setName('skip').setDescription('Skip current track'))
    .addSubcommand(s => s.setName('stop').setDescription('Stop and clear queue'))
    .addSubcommand(s => s.setName('queue').setDescription('Show current queue'))
    .addSubcommand(s => s.setName('pause').setDescription('Pause playback'))
    .addSubcommand(s => s.setName('resume').setDescription('Resume playback'))
    .addSubcommand(s => s.setName('loop').setDescription('Toggle loop mode'))
    .addSubcommand(s => s
      .setName('volume')
      .setDescription('Set volume (0–100)')
      .addIntegerOption(o => o.setName('level').setDescription('Volume level').setRequired(true).setMinValue(0).setMaxValue(100))
    ),

  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guildId;
    const q = getQueue(client, guildId);
    q.textChannel = interaction.channel;

    // ── PLAY ──────────────────────────────────────────────────────────────
    if (sub === 'play') {
      const voiceChannel = interaction.member.voice?.channel;
      if (!voiceChannel) return interaction.reply({ embeds: [errorEmbed('Not in Voice', 'Join a voice channel first!')], ephemeral: true });

      await interaction.deferReply();
      const query = interaction.options.getString('query');

      try {
        let info;
        if (play.yt_validate(query) === 'video') {
          const result = await play.video_info(query);
          info = result.video_details;
        } else {
          const searched = await play.search(query, { limit: 1 });
          if (!searched.length) return interaction.editReply({ embeds: [errorEmbed('Not Found', `No results for \`${query}\``)] });
          info = searched[0];
        }

        const track = {
          title:       info.title ?? 'Unknown',
          url:         info.url,
          duration:    info.durationRaw ?? '?',
          thumbnail:   info.thumbnails?.[0]?.url ?? null,
          requestedBy: interaction.user.id,
        };

        q.tracks.push(track);

        // Connect if not already
        if (!q.connection || q.connection.state.status === VoiceConnectionStatus.Destroyed) {
          q.connection = joinVoiceChannel({
            channelId:      voiceChannel.id,
            guildId,
            adapterCreator: interaction.guild.voiceAdapterCreator,
          });
          q.player = createAudioPlayer();
          q.connection.subscribe(q.player);

          q.player.on(AudioPlayerStatus.Idle, () => {
            if (q.loop && q.current) q.tracks.unshift(q.current);
            playNext(client, guildId);
          });
          q.player.on('error', err => {
            console.error('[Music] Player error:', err.message);
            playNext(client, guildId);
          });
        }

        if (q.player.state.status === AudioPlayerStatus.Idle) {
          await interaction.editReply({ embeds: [successEmbed('Loading', `Loading **${track.title}**...`)] });
          playNext(client, guildId);
        } else {
          await interaction.editReply({
            embeds: [new EmbedBuilder()
              .setColor(0x1db954)
              .setTitle('➕ Added to Queue')
              .setDescription(`**[${track.title}](${track.url})**`)
              .addFields(
                { name: 'Position', value: `#${q.tracks.length}`, inline: true },
                { name: 'Duration', value: track.duration, inline: true },
              )
              .setThumbnail(track.thumbnail)
              .setTimestamp()
            ],
          });
        }
      } catch (err) {
        await interaction.editReply({ embeds: [errorEmbed('Error', err.message)] });
      }
    }

    // ── SKIP ──────────────────────────────────────────────────────────────
    else if (sub === 'skip') {
      if (!q.current) return interaction.reply({ embeds: [errorEmbed('Nothing Playing', 'Nothing to skip.')] });
      q.player?.stop();
      await interaction.reply({ embeds: [successEmbed('Skipped', `Skipped **${q.current.title}**`)] });
    }

    // ── STOP ──────────────────────────────────────────────────────────────
    else if (sub === 'stop') {
      q.tracks = [];
      q.current = null;
      q.player?.stop();
      q.connection?.destroy();
      client.musicQueues.delete(guildId);
      await interaction.reply({ embeds: [successEmbed('Stopped', 'Queue cleared and bot left.')] });
    }

    // ── QUEUE ─────────────────────────────────────────────────────────────
    else if (sub === 'queue') {
      if (!q.current && !q.tracks.length) {
        return interaction.reply({ embeds: [infoEmbed('Queue Empty', 'Nothing playing.')] });
      }
      const list = q.tracks.slice(0, 10).map((t, i) => `${i + 1}. [${t.title}](${t.url}) — <@${t.requestedBy}>`).join('\n');
      const embed = new EmbedBuilder()
        .setColor(0x1db954)
        .setTitle('🎵 Queue')
        .setDescription(
          `**Now Playing:** ${q.current ? `[${q.current.title}](${q.current.url})` : 'Nothing'}\n\n` +
          (list || 'Queue is empty.')
        )
        .setFooter({ text: `${q.tracks.length} tracks • Loop: ${q.loop ? 'ON' : 'OFF'} • Vol: ${Math.round(q.volume * 100)}%` })
        .setTimestamp();
      await interaction.reply({ embeds: [embed] });
    }

    // ── PAUSE / RESUME ─────────────────────────────────────────────────────
    else if (sub === 'pause') {
      q.player?.pause();
      await interaction.reply({ embeds: [successEmbed('Paused', 'Music paused.')] });
    }
    else if (sub === 'resume') {
      q.player?.unpause();
      await interaction.reply({ embeds: [successEmbed('Resumed', 'Music resumed.')] });
    }

    // ── LOOP ──────────────────────────────────────────────────────────────
    else if (sub === 'loop') {
      q.loop = !q.loop;
      await interaction.reply({ embeds: [successEmbed('Loop', `Loop is now **${q.loop ? 'ON' : 'OFF'}**`)] });
    }

    // ── VOLUME ────────────────────────────────────────────────────────────
    else if (sub === 'volume') {
      const level = interaction.options.getInteger('level') / 100;
      q.volume = level;
      // apply to current resource if playing
      if (q.player?.state?.resource?.volume) {
        q.player.state.resource.volume.setVolume(level);
      }
      await interaction.reply({ embeds: [successEmbed('Volume', `Volume set to **${Math.round(level * 100)}%**`)] });
    }
  },
};
