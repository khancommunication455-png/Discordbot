import { SlashCommandBuilder, ChannelType, EmbedBuilder } from 'discord.js';
import { setupTTS, stopTTS, getTTSState, enqueueTTS, clearTTSQueue } from '../../services/ttsService.js';
import { getDb, saveDb } from '../../utils/db.js';
import { successEmbed, errorEmbed, infoEmbed } from '../../utils/embeds.js';

export default {
  data: new SlashCommandBuilder()
    .setName('tts')
    .setDescription('Text-to-Speech — reads a text channel aloud in voice (Roman Urdu & Hindi supported)')
    .addSubcommand(s => s
      .setName('start')
      .setDescription('Start TTS — bot joins voice and reads messages from a text channel')
      .addChannelOption(o =>
        o.setName('text_channel')
         .setDescription('Text channel whose messages will be read aloud')
         .addChannelTypes(ChannelType.GuildText)
         .setRequired(true)
      )
      .addChannelOption(o =>
        o.setName('voice_channel')
         .setDescription('Voice channel to join (optional — auto-picks if not set)')
         .addChannelTypes(ChannelType.GuildVoice)
         .setRequired(false)
      )
    )
    .addSubcommand(s => s
      .setName('stop')
      .setDescription('Stop TTS and leave the voice channel')
    )
    .addSubcommand(s => s
      .setName('say')
      .setDescription('Make TTS say something immediately')
      .addStringOption(o =>
        o.setName('text').setDescription('What to say').setRequired(true)
      )
    )
    .addSubcommand(s => s
      .setName('skip')
      .setDescription('Skip the current message and clear the queue')
    )
    .addSubcommand(s => s
      .setName('status')
      .setDescription('Check TTS status')
    ),

  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });

    const sub = interaction.options.getSubcommand();
    const db  = getDb();

    // ── START ─────────────────────────────────────────────────────────────
    if (sub === 'start') {
      const textChannel = interaction.options.getChannel('text_channel');

      // Resolve voice channel — 4 fallback levels
      let voiceChannel = interaction.options.getChannel('voice_channel')
        ?? interaction.member.voice?.channel
        ?? interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildVoice && c.members.size > 0)
        ?? interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildVoice)
        ?? null;

      if (!voiceChannel) {
        return interaction.editReply({
          embeds: [errorEmbed('No Voice Channel',
            'Could not find a voice channel to join.\n' +
            'Join one yourself, or use the `voice_channel` option to specify one.'
          )],
        });
      }

      try {
        await setupTTS(interaction.guild, voiceChannel.id);

        db.data.ttsChannels[interaction.guildId]     = textChannel.id;
        db.data.ttsVoiceChannel[interaction.guildId] = voiceChannel.id;
        await saveDb();

        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle('🔊 TTS Active')
          .setDescription(
            `Reading messages from <#${textChannel.id}> in **${voiceChannel.name}**\n\n` +
            `**Voices:**\n` +
            `• Roman Urdu → *bhai kya haal, yaar* → Brian voice (reads naturally)\n` +
            `• اردو script → Google Urdu voice\n` +
            `• हिन्दी → Google Hindi voice\n` +
            `• English → Brian (StreamElements)\n\n` +
            `Type anything in <#${textChannel.id}> and I'll read it!`
          )
          .addFields(
            { name: '📝 Reading',   value: `<#${textChannel.id}>`,  inline: true },
            { name: '🔊 Speaking',  value: `**${voiceChannel.name}**`, inline: true },
          )
          .setFooter({ text: '/tts stop to stop • /tts skip to clear queue' })
          .setTimestamp();

        return interaction.editReply({ embeds: [embed] });
      } catch (err) {
        return interaction.editReply({ embeds: [errorEmbed('TTS Error', err.message)] });
      }
    }

    // ── STOP ──────────────────────────────────────────────────────────────
    if (sub === 'stop') {
      stopTTS(interaction.guildId);
      delete db.data.ttsChannels[interaction.guildId];
      delete db.data.ttsVoiceChannel[interaction.guildId];
      await saveDb();
      return interaction.editReply({ embeds: [successEmbed('TTS Stopped', 'Left the voice channel.')] });
    }

    // ── SAY ───────────────────────────────────────────────────────────────
    if (sub === 'say') {
      const state = getTTSState(interaction.guildId);
      if (!state) {
        return interaction.editReply({
          embeds: [errorEmbed('Not Active', 'Use `/tts start #channel` first.')],
        });
      }
      const text = interaction.options.getString('text');
      const ok   = await enqueueTTS(interaction.guild, text, interaction.user.username);
      return interaction.editReply({
        embeds: [ok
          ? successEmbed('Speaking ✅', `"${text.slice(0, 100)}"`)
          : errorEmbed('Error', 'Could not queue message.')
        ],
      });
    }

    // ── SKIP ──────────────────────────────────────────────────────────────
    if (sub === 'skip') {
      const state = getTTSState(interaction.guildId);
      if (!state) {
        return interaction.editReply({ embeds: [errorEmbed('Not Active', 'TTS is not running.')] });
      }
      clearTTSQueue(interaction.guildId);
      state.player?.stop(); // stops current, triggers Idle → processQueue with empty queue
      return interaction.editReply({ embeds: [successEmbed('Skipped', 'Queue cleared.')] });
    }

    // ── STATUS ────────────────────────────────────────────────────────────
    if (sub === 'status') {
      const state   = getTTSState(interaction.guildId);
      const ttsChId = db.data.ttsChannels?.[interaction.guildId];
      const vcId    = db.data.ttsVoiceChannel?.[interaction.guildId];

      if (!state) {
        return interaction.editReply({
          embeds: [infoEmbed('TTS Status', '❌ Not active. Use `/tts start #channel`')],
        });
      }

      return interaction.editReply({
        embeds: [new EmbedBuilder()
          .setColor(0x57f287)
          .setTitle('🔊 TTS — Active')
          .addFields(
            { name: '📝 Text Channel',  value: ttsChId ? `<#${ttsChId}>` : '?', inline: true },
            { name: '🔊 Voice Channel', value: vcId    ? `<#${vcId}>`    : '?', inline: true },
            { name: '📋 Queue',         value: `${state.queue.length} pending`,  inline: true },
            { name: '🎵 Playing',       value: state.active ? 'Yes' : 'No',      inline: true },
          )
          .setTimestamp()
        ],
      });
    }
  },
};
