/**
 * download.js — SkyBot v2 Social Media Downloader (6 YouTube clients)
 */
import { SlashCommandBuilder, AttachmentBuilder, EmbedBuilder } from 'discord.js';
import { existsSync, unlinkSync, mkdirSync, readdirSync, statSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { exec, execSync } from 'child_process';
import { promisify } from 'util';
import { C } from '../../utils/embeds.js';

const execAsync = promisify(exec);
const __dirname = dirname(fileURLToPath(import.meta.url));
const TMP_DIR = join(__dirname, '../../../tmp');
const FOOTER = { text: 'SkyBot v2 • Railway Edition' };
const DISCORD_MAX_BYTES = 25 * 1024 * 1024;

if (!existsSync(TMP_DIR)) mkdirSync(TMP_DIR, { recursive: true });

function findYtDlp() {
  for (const p of ['yt-dlp', '/root/.nix-profile/bin/yt-dlp', '/usr/bin/yt-dlp', '/usr/local/bin/yt-dlp']) {
    try { if (p === 'yt-dlp') { execSync('yt-dlp --version', { stdio: 'pipe', timeout: 5000 }); return p; } if (existsSync(p)) return p; } catch {}
  }
  return 'yt-dlp';
}
const ytdlp = findYtDlp();
const PLAYER_CLIENTS = ['tv', 'web_embedded', 'web_safari', 'web', 'android', 'ios'];

export default {
  data: new SlashCommandBuilder().setName('download').setDescription('Download video/audio from social media')
    .addStringOption(o => o.setName('url').setDescription('Video URL (YouTube, TikTok, etc.)').setRequired(true))
    .addStringOption(o => o.setName('quality').setDescription('Download quality').setRequired(false)
      .addChoices({ name: 'Best available', value: 'best' }, { name: '1080p', value: '1080' }, { name: '720p', value: '720' }, { name: '480p', value: '480' }, { name: 'Audio only (MP3)', value: 'audio' })),
  cooldown: 5,
  async execute(interaction) {
    await interaction.deferReply();
    const url = interaction.options.getString('url');
    const quality = interaction.options.getString('quality') ?? 'best';
    if (!/^https?:\/\//.test(url)) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.error).setTitle('❌ Invalid URL').setDescription('Provide a valid URL.').setFooter(FOOTER).setTimestamp()] });

    const ts = Date.now();
    const outTpl = join(TMP_DIR, `dl_${ts}.%(ext)s`);
    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.info).setTitle('⬇️ Downloading...').setDescription(`**URL:** ${url.slice(0, 80)}\n**Quality:** ${quality === 'audio' ? 'MP3' : quality}`).setFooter(FOOTER).setTimestamp()] });

    let formatArg;
    if (quality === 'audio') formatArg = `-x --audio-format mp3 --audio-quality 0 -f "bestaudio/best"`;
    else if (quality === 'best') formatArg = `-f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best"`;
    else formatArg = `-f "bestvideo[height<=${quality}][ext=mp4]+bestaudio[ext=m4a]/best[height<=${quality}]/best"`;

    let downloadSuccess = false, lastError = null;
    for (const client of PLAYER_CLIENTS) {
      const cmd = `"${ytdlp}" ${formatArg} --no-playlist --max-filesize 24M --no-warnings --no-cookies --no-check-certificates --extractor-args "youtube:player_client=${client}" -o "${outTpl}" "${url}"`;
      try { await execAsync(cmd, { timeout: 120000, maxBuffer: 50 * 1024 * 1024 }); downloadSuccess = true; console.log(`[Download] ${client} ✅`); break; }
      catch (err) { lastError = err; console.warn(`[Download] ${client} failed: ${String(err.stderr||err.message||err).slice(0,120)}`); try { readdirSync(TMP_DIR).filter(f => f.startsWith(`dl_${ts}`)).forEach(f => { try { unlinkSync(join(TMP_DIR, f)); } catch {} }); } catch {} }
    }

    if (!downloadSuccess) {
      const errStr = String(lastError?.stderr || lastError?.message || lastError);
      let msg;
      if (errStr.includes('Sign in to confirm') || errStr.includes('not a bot')) msg = 'YouTube is blocking the bot. Try a different video or use a direct URL.';
      else if (errStr.includes('Instagram') && errStr.includes('empty media')) msg = 'Instagram requires login. Only public posts can be downloaded.';
      else if (errStr.includes('page needs to be reloaded')) msg = 'YouTube is temporarily blocking. Try again in a few minutes.';
      else msg = `Download failed: ${errStr.slice(0, 300)}`;
      return interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.error).setTitle('❌ Download Failed').setDescription(msg).setFooter(FOOTER).setTimestamp()] });
    }

    const files = readdirSync(TMP_DIR).filter(f => f.startsWith(`dl_${ts}`) && !f.endsWith('.part') && !f.endsWith('.ytdl')).map(f => join(TMP_DIR, f));
    if (!files.length) return interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.error).setTitle('❌ Download Failed').setDescription('Output file not found.').setFooter(FOOTER).setTimestamp()] });

    const filePath = files[0];
    const ext = filePath.split('.').pop() ?? 'mp4';
    const fileSize = statSync(filePath).size;

    if (fileSize > DISCORD_MAX_BYTES) {
      try { unlinkSync(filePath); } catch {}
      const sizeMB = (fileSize / 1024 / 1024).toFixed(1);
      return interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.warning).setTitle('⚠️ File Too Large').setDescription(`File is **${sizeMB}MB** — exceeds Discord's 25MB limit.\nTry \`/download quality:audio\` for a smaller file.`).setFooter(FOOTER).setTimestamp()] });
    }

    let title = 'video';
    for (const client of PLAYER_CLIENTS) { try { const r = await execAsync(`"${ytdlp}" --get-title --no-playlist --no-cookies --no-check-certificates --extractor-args "youtube:player_client=${client}" "${url}" 2>/dev/null`, { timeout: 10000 }); title = (r.stdout?.trim() || 'video').slice(0, 60); if (title !== 'video') break; } catch {} }

    const safeName = (title || 'video').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '_') || 'video';
    const attachment = new AttachmentBuilder(filePath, { name: `${safeName}.${ext}` });
    const sizeMB = (fileSize / 1024 / 1024).toFixed(2);

    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(C.success).setTitle('✅ Download Complete').setDescription(`**${title}**`).addFields({ name: 'Quality', value: quality === 'audio' ? 'MP3' : quality, inline: true }, { name: 'Size', value: `${sizeMB} MB`, inline: true }).setFooter(FOOTER).setTimestamp()], files: [attachment] });
    setTimeout(() => { try { unlinkSync(filePath); } catch {} }, 30000);
  },
};
